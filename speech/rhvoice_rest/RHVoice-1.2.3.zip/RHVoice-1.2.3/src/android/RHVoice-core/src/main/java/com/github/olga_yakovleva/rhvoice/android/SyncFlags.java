package com.github.olga_yakovleva.rhvoice.android;

public final class SyncFlags
{
    public static final long LOCAL=1;
    public static final long NETWORK=2;
}
